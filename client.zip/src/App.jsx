import React from "react";
import Navbar from "./Components/Pages/Navbar";
import './App.css'
import Home from "./Components/Pages/Home";
function App() {
  return (
    <div className="App">
      <Navbar />
      
      <Home/>

      
      {/* Your content here */}
    </div>
  );
}

export default App;
